import { useEffect, useRef, useState } from 'react'
import './App.css'

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
const initialProfile = { fullName: '', email: '', location: '', headline: '', bio: '', goals: '', skills: [] }

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  })
  const result = await response.json()
  if (!response.ok) throw new Error(result.message || 'Something went wrong. Please try again.')
  return result
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(() => Boolean(localStorage.getItem('womenToken')))
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('womenUser') || 'null') } catch { return null }
  })
  const [authMode, setAuthMode] = useState('login')
  const [activeTab, setActiveTab] = useState('overview')
  const [authForm, setAuthForm] = useState({ fullName: '', email: '', password: '' })
  const [profile, setProfile] = useState(initialProfile)
  const [jobs, setJobs] = useState([])
  const [posts, setPosts] = useState([])
  const [mentors, setMentors] = useState([])
  const [requests, setRequests] = useState([])
  const [adminData, setAdminData] = useState(null)
  const [savedJobs, setSavedJobs] = useState(() => JSON.parse(localStorage.getItem('womenSavedJobs') || '[]'))
  const [status, setStatus] = useState({ type: '', message: '' })
  const [mentorshipForm, setMentorshipForm] = useState({ area: '', mentor: '', message: '' })
  const [postText, setPostText] = useState('')
  const [commentDrafts, setCommentDrafts] = useState({})
  const [jobMessages, setJobMessages] = useState({})
  const [search, setSearch] = useState('')
  const requestListRef = useRef(null)
  const applicationsRef = useRef(null)
  const communityRef = useRef(null)
  const mentorListRef = useRef(null)
  const jobsListRef = useRef(null)
  const profileFormRef = useRef(null)
  const pendingScrollRef = useRef(null)
  const preferredMentorRef = useRef(null)

  useEffect(() => {
    let ignore = false
    const loadPlatformData = async () => {
      try {
        const [profileResult, jobsResult, communityResult, mentorshipResult, adminResult] = await Promise.all([
          request('/profile'), request('/jobs'), request('/community'), request('/mentorship'), request('/admin/dashboard'),
        ])
        if (ignore) return
        setProfile({ ...profileResult.profile, ...(user?.fullName ? { fullName: user.fullName } : {}), ...(user?.email ? { email: user.email } : {}) })
        setJobs(jobsResult.jobs)
        setPosts(communityResult.posts)
        setMentors(mentorshipResult.mentors)
        setRequests(mentorshipResult.requests)
        setAdminData(adminResult)
      } catch (error) {
        if (!ignore) setStatus({ type: 'error', message: `Could not connect to the platform API: ${error.message}` })
      }
    }
    loadPlatformData()
    return () => { ignore = true }
  }, [user])

  useEffect(() => {
    const target = pendingScrollRef.current
    if (!target) return

    pendingScrollRef.current = null
    target.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }, [activeTab])

  const navigateToSection = (tab, targetRef) => {
    pendingScrollRef.current = targetRef
    if (activeTab === tab) {
      requestAnimationFrame(() => {
        targetRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
        pendingScrollRef.current = null
      })
      return
    }
    setActiveTab(tab)
  }

  const handleAuth = async (event) => {
    event.preventDefault()
    setStatus({ type: 'loading', message: authMode === 'login' ? 'Signing in...' : 'Creating account...' })
    try {
      const result = await request(`/auth/${authMode}`, { method: 'POST', body: JSON.stringify(authForm) })
      localStorage.setItem('womenToken', result.token)
      localStorage.setItem('womenUser', JSON.stringify(result.user))
      setUser(result.user)
      setIsAuthenticated(true)
      setAuthForm({ fullName: '', email: '', password: '' })
      setStatus({ type: 'success', message: result.message })
    } catch (error) { setStatus({ type: 'error', message: error.message }) }
  }

  const logout = () => {
    localStorage.removeItem('womenToken')
    localStorage.removeItem('womenUser')
    setUser(null)
    setIsAuthenticated(false)
    setStatus({ type: '', message: '' })
  }

  const saveProfile = async (event) => {
    event.preventDefault()
    try {
      const result = await request('/profile', { method: 'PUT', body: JSON.stringify({ ...profile, skills: Array.isArray(profile.skills) ? profile.skills : profile.skills.split(',').map((skill) => skill.trim()) }) })
      setProfile(result.profile)
      if (user) {
        const updatedUser = { ...user, fullName: result.profile.fullName, email: result.profile.email }
        setUser(updatedUser)
        localStorage.setItem('womenUser', JSON.stringify(updatedUser))
      }
      setStatus({ type: 'success', message: 'Your profile has been updated.' })
    } catch (error) { setStatus({ type: 'error', message: error.message }) }
  }

  const submitMentorship = async (event) => {
    event.preventDefault()
    try {
      const result = await request('/mentorship', { method: 'POST', body: JSON.stringify({ name: profile.fullName, email: profile.email, ...mentorshipForm }) })
      setRequests((current) => [result.request, ...current])
      setMentorshipForm({ area: '', mentor: '', message: '' })
      setStatus({ type: 'success', message: result.message })
    } catch (error) { setStatus({ type: 'error', message: error.message }) }
  }

  const chooseMentor = (mentorName) => {
    setMentorshipForm((current) => ({
      ...current,
      mentor: current.mentor === mentorName ? '' : mentorName,
    }))
    preferredMentorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    preferredMentorRef.current?.focus({ preventScroll: true })
  }

  const deleteMentorshipRequest = async (mentorshipRequest) => {
    if (!window.confirm(`Delete the mentorship request from ${mentorshipRequest.name}?`)) return

    try {
      const result = await request(`/mentorship/${mentorshipRequest.id}`, { method: 'DELETE' })
      setRequests((current) => current.filter((item) => item.id !== mentorshipRequest.id))
      const updated = await request('/admin/dashboard')
      setAdminData(updated)
      setStatus({ type: 'success', message: result.message })
    } catch (error) {
      setStatus({ type: 'error', message: error.message })
    }
  }

  const deleteJobApplication = async (application) => {
    if (!window.confirm(`Delete your application for ${application.title} at ${application.company}?`)) return

    try {
      const result = await request(`/jobs/applications/${application.id}`, { method: 'DELETE' })
      const updated = await request('/admin/dashboard')
      setAdminData(updated)
      setStatus({ type: 'success', message: result.message })
    } catch (error) {
      setStatus({ type: 'error', message: error.message })
    }
  }

  const toggleSavedJob = (jobId) => {
    const next = savedJobs.includes(jobId) ? savedJobs.filter((id) => id !== jobId) : [...savedJobs, jobId]
    setSavedJobs(next)
    localStorage.setItem('womenSavedJobs', JSON.stringify(next))
  }

  const applyToJob = async (job) => {
    try {
      const result = await request(`/jobs/${job.id}/apply`, { method: 'POST', body: JSON.stringify({ name: profile.fullName, email: profile.email }) })
      setJobMessages((current) => ({ ...current, [job.id]: result.message }))
      const updated = await request('/admin/dashboard')
      setAdminData(updated)
    } catch (error) { setJobMessages((current) => ({ ...current, [job.id]: error.message })) }
  }

  const createPost = async (event) => {
    event.preventDefault()
    if (!postText.trim()) return
    try {
      const result = await request('/community', { method: 'POST', body: JSON.stringify({ author: profile.fullName || 'Community member', content: postText }) })
      setPosts((current) => [result.post, ...current])
      setPostText('')
      setStatus({ type: 'success', message: 'Your post is live.' })
    } catch (error) { setStatus({ type: 'error', message: error.message }) }
  }

  const toggleLike = async (post) => {
    try {
      const result = await request(`/community/${post.id}/like`, { method: 'POST', body: JSON.stringify({ userId: user?.id || profile.email || 'community-guest' }) })
      setPosts((current) => current.map((item) => item.id === post.id ? result.post : item))
    } catch (error) { setStatus({ type: 'error', message: error.message }) }
  }

  const addComment = async (event, post) => {
    event.preventDefault()
    const text = commentDrafts[post.id]?.trim()
    if (!text) return
    try {
      const result = await request(`/community/${post.id}/comments`, { method: 'POST', body: JSON.stringify({ author: profile.fullName || 'Community member', text }) })
      setPosts((current) => current.map((item) => item.id === post.id ? result.post : item))
      setCommentDrafts((current) => ({ ...current, [post.id]: '' }))
    } catch (error) { setStatus({ type: 'error', message: error.message }) }
  }

  const tabs = [
    ['overview', 'Overview'], ['profile', 'My profile'], ['mentorship', 'Mentorship'],
    ['jobs', `Opportunities${savedJobs.length ? ` · ${savedJobs.length}` : ''}`], ['community', 'Community'],
    ['admin', user?.role === 'admin' || user?.role === 'mentor' ? 'Mentor dashboard' : 'Coordinator view'],
  ]

  if (!isAuthenticated) return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-wrap"><div className="brand-mark">WE</div><div><p className="brand-name">Women Empowerment</p><small>Support Platform</small></div></div>
        <nav className="main-nav"><a href="#platform">Platform</a><a href="#features">What you can do</a><a href="#impact">Our impact</a></nav>
        <button type="button" className="nav-button" onClick={() => document.getElementById('account')?.scrollIntoView({ behavior: 'smooth' })}>Join Now</button>
      </header>
      <main>
        <section className="hero-section" id="platform">
          <div className="hero-copy"><span className="eyebrow">Empower. Learn. Grow.</span><h1>A place to find your next opportunity.</h1><p>Build your confidence, connect with mentors, discover meaningful work, and grow alongside a community that wants to see you thrive.</p><div className="cta-group"><button className="primary-btn" type="button" onClick={() => { setAuthMode('register'); document.getElementById('account')?.scrollIntoView({ behavior: 'smooth' }) }}>Create your free account</button><a className="secondary-btn" href="#features">Explore the platform</a></div><div className="mini-stats"><div className="mini-card"><strong>1.8K+</strong><span>supportive mentors</span></div><div className="mini-card"><strong>4.5K</strong><span>opportunities shared</span></div></div></div>
          <div className="auth-panel" id="account"><div className="auth-card"><span className="eyebrow">Your community is waiting</span><h2 className="auth-title">{authMode === 'login' ? 'Welcome back' : 'Start your journey'}</h2><div className="auth-toggle"><button className={authMode === 'login' ? 'active' : ''} type="button" onClick={() => setAuthMode('login')}>Login</button><button className={authMode === 'register' ? 'active' : ''} type="button" onClick={() => setAuthMode('register')}>Register</button></div><form className="auth-form" onSubmit={handleAuth}>{authMode === 'register' && <label><span>Full name</span><input required value={authForm.fullName} onChange={(event) => setAuthForm({ ...authForm, fullName: event.target.value })} placeholder="Your name" /></label>}<label><span>Email address</span><input required type="email" value={authForm.email} onChange={(event) => setAuthForm({ ...authForm, email: event.target.value })} placeholder="you@example.com" /></label><label><span>Password</span><input required type="password" minLength="6" value={authForm.password} onChange={(event) => setAuthForm({ ...authForm, password: event.target.value })} placeholder="At least 6 characters" /></label>{status.message && <p className={`status-message ${status.type}`}>{status.message}</p>}<button type="submit" className="submit-btn">{authMode === 'login' ? 'Sign in' : 'Create my account'}</button></form></div></div>
        </section>
        <section className="features-section" id="features"><div className="section-header"><span className="eyebrow">A platform for your next step</span><h2>Support that grows with you</h2></div><div className="modules-grid">{[['Mentorship', 'Get thoughtful guidance from women who have been there.'], ['Career opportunities', 'Find roles, save the ones you love, and apply in a few clicks.'], ['Community', 'Share a win, ask a question, and learn together.']].map(([title, description]) => <article className="module-card" key={title}><span className="module-badge">For you</span><h3>{title}</h3><p>{description}</p></article>)}</div></section>
        <section className="impact-section" id="impact"><div className="impact-copy"><span className="eyebrow">Progress is better together</span><h2>Build confidence, opportunity, and belonging.</h2><p>From your first career conversation to your next big idea, find practical support for every step.</p></div><ul className="impact-list"><li>Personal profile to share your goals and strengths</li><li>Mentor matching for business and career growth</li><li>Curated jobs and supportive community conversations</li></ul></section>
      </main><footer className="footer"><p>Women Empowerment & Support Platform</p><span>Connecting skills, opportunities, and community</span></footer>
    </div>
  )

  const filteredJobs = jobs.filter((job) => `${job.title} ${job.company} ${job.category} ${job.location}`.toLowerCase().includes(search.toLowerCase()))
  return (
    <div className="app-shell">
      <header className="topbar"><div className="brand-wrap"><div className="brand-mark">WE</div><div><p className="brand-name">Women Empowerment</p><small>Support Platform</small></div></div><div className="topbar-actions"><span className="welcome-label">Welcome, {user?.fullName?.split(' ')[0] || 'friend'}</span><button className="nav-button" type="button" onClick={logout}>Sign out</button></div></header>
      <main className="dashboard-shell"><section className="dashboard-hero"><div><span className="eyebrow">Your space to grow</span><h1>{activeTab === 'overview' ? `Good to see you, ${user?.fullName?.split(' ')[0] || 'friend'}.` : tabs.find(([key]) => key === activeTab)?.[1]}</h1><p>Small steps, strong support, and new possibilities start here.</p></div><div className="user-chip">{user?.role || 'Member'}</div></section>
        <nav className="tab-nav" aria-label="Platform sections">{tabs.map(([key, label]) => <button key={key} type="button" className={`tab-button ${activeTab === key ? 'active' : ''}`} onClick={() => { setActiveTab(key); setStatus({ type: '', message: '' }) }}>{label}</button>)}</nav>
        {status.message && <p className={`status-message dashboard-status ${status.type}`} role="status">{status.message}</p>}
        <div className="tab-content">
          {activeTab === 'overview' && <><section className="dashboard-grid">{[["Mentorship requests", requests.length, 'View requests', 'admin', requestListRef], ["Saved opportunities", savedJobs.length, 'View opportunities', 'jobs', jobsListRef], ["Community posts", posts.length, 'Open community', 'community', communityRef], ["New connections", '12', 'Meet mentors', 'mentorship', mentorListRef]].map(([label, value, action, tab, targetRef]) => <button className="dashboard-card dashboard-card-button" key={label} type="button" onClick={() => navigateToSection(tab, targetRef)}><span>{label}</span><strong>{value}</strong><small>{action}</small></button>)}</section><section className="dashboard-panels"><article className="panel-box"><span className="eyebrow">A good next step</span><h3>Talk it through with a mentor</h3><p>Get a fresh perspective on your business, career, or next big decision.</p><button className="primary-btn" type="button" onClick={() => navigateToSection('mentorship', mentorListRef)}>Explore mentors</button></article><article className="panel-box"><span className="eyebrow">Made for you</span><h3>Your profile tells your story</h3><p>Add your goals and skills so the community can support you in more useful ways.</p><button className="secondary-btn" type="button" onClick={() => navigateToSection('profile', profileFormRef)}>Update profile</button></article></section><p className="demo-note">Your activity and saved roles are kept in this browser for this demo.</p></>}
          {activeTab === 'profile' && <div className="profile-layout"><aside className="profile-summary"><div className="avatar-circle">{(profile.fullName || 'W').split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase()}</div><h2>{profile.fullName}</h2><p className="summary-headline">{profile.headline || 'Add a headline that describes what you do.'}</p><p className="muted">{profile.location || 'Add your location'}</p><div className="summary-divider"/><span className="module-badge">Your focus</span><p>{profile.goals || 'Tell your community what you are working toward.'}</p><div className="skill-list">{(Array.isArray(profile.skills) ? profile.skills : []).map((skill) => <span key={skill}>{skill}</span>)}</div></aside><form className="form-card profile-form" ref={profileFormRef} onSubmit={saveProfile}><div className="form-heading"><span className="eyebrow">Your story</span><h2>Edit your profile</h2><p>Help mentors and peers understand where you are headed.</p></div><div className="form-grid"><label>Full name<input required value={profile.fullName || ''} onChange={(event) => setProfile({ ...profile, fullName: event.target.value })}/></label><label>Email address<input required type="email" value={profile.email || ''} onChange={(event) => setProfile({ ...profile, email: event.target.value })}/></label><label>Location<input value={profile.location || ''} onChange={(event) => setProfile({ ...profile, location: event.target.value })} placeholder="City, country"/></label><label>Professional headline<input value={profile.headline || ''} onChange={(event) => setProfile({ ...profile, headline: event.target.value })} placeholder="Your role or business"/></label><label className="full-width">About you<textarea rows="4" value={profile.bio || ''} onChange={(event) => setProfile({ ...profile, bio: event.target.value })} placeholder="Share what motivates you..."/></label><label className="full-width">Skills <small>Separate skills with commas</small><input value={(Array.isArray(profile.skills) ? profile.skills : []).join(', ')} onChange={(event) => setProfile({ ...profile, skills: event.target.value.split(',').map((skill) => skill.trim()) })} placeholder="Leadership, design, finance"/></label><label className="full-width">What are you working toward?<textarea rows="3" value={profile.goals || ''} onChange={(event) => setProfile({ ...profile, goals: event.target.value })} placeholder="A goal you would like support with"/></label></div><button className="primary-btn" type="submit">Save profile</button></form></div>}
          {activeTab === 'mentorship' && <div className="mentorship-layout"><section><div className="section-header"><span className="eyebrow">People in your corner</span><h2>Meet your mentors</h2><p>Choose someone whose experience fits the question on your mind.</p></div><div className="mentor-list" ref={mentorListRef}>{mentors.map((mentor) => { const selected = mentorshipForm.mentor === mentor.name; return <article className={`mentor-card ${selected ? 'selected' : ''}`} key={mentor.name}><div className="mentor-avatar">{mentor.name.split(' ').map((part) => part[0]).join('')}</div><div><h3>{mentor.name}</h3><p>{mentor.expertise}</p><small>{mentor.availability}</small></div><button className={`text-action ${selected ? 'selected' : ''}`} type="button" onClick={() => chooseMentor(mentor.name)} aria-pressed={selected}>{selected ? 'Selected ✓' : 'Choose mentor'}</button></article>})}</div></section><form className="form-card" onSubmit={submitMentorship}><span className="eyebrow">Start a conversation</span><h2>Request mentorship</h2><p>Tell us what you would like to work on. A coordinator will help with the next step.</p><label>Focus area<select required value={mentorshipForm.area} onChange={(event) => setMentorshipForm({ ...mentorshipForm, area: event.target.value })}><option value="">Choose a focus area</option><option>Career growth</option><option>Business growth</option><option>Leadership</option><option>Digital skills</option><option>Confidence and wellbeing</option></select></label><label>Preferred mentor<select ref={preferredMentorRef} value={mentorshipForm.mentor} onChange={(event) => setMentorshipForm({ ...mentorshipForm, mentor: event.target.value })}><option value="">Open to recommendations</option>{mentors.map((mentor) => <option key={mentor.name}>{mentor.name}</option>)}</select></label><label>What would you like guidance on?<textarea required minLength="12" rows="5" value={mentorshipForm.message} onChange={(event) => setMentorshipForm({ ...mentorshipForm, message: event.target.value })} placeholder="A little context helps us make a thoughtful match..."/></label><button className="primary-btn" type="submit">Send request</button></form></div>}
          {activeTab === 'jobs' && <div ref={jobsListRef}><div className="section-header list-heading"><div><span className="eyebrow">Find your next move</span><h2>Opportunities for you</h2><p>{savedJobs.length} saved · {jobs.length} opportunities selected for this community</p></div><label className="search-box"><span className="sr-only">Search opportunities</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search roles or skills"/></label></div><div className="jobs-list">{filteredJobs.map((job) => <article className="job-card" key={job.id}><div className="job-icon">{job.company.slice(0, 1)}</div><div className="job-main"><div className="job-meta"><span className="module-badge">{job.type}</span><span>{job.category}</span></div><h3>{job.title}</h3><p className="job-company">{job.company} <span>·</span> {job.location}</p><p>{job.description}</p><small>{job.salary}</small>{jobMessages[job.id] && <p className="inline-feedback">{jobMessages[job.id]}</p>}</div><div className="job-actions"><button className={`save-button ${savedJobs.includes(job.id) ? 'saved' : ''}`} type="button" onClick={() => toggleSavedJob(job.id)}>{savedJobs.includes(job.id) ? '? Saved' : '? Save'}</button><button className="primary-btn" type="button" onClick={() => applyToJob(job)}>Apply now</button></div></article>)}{filteredJobs.length === 0 && <div className="empty-state">No roles match that search yet. Try another keyword.</div>}</div></div>}
          {activeTab === 'community' && <div className="community-layout" ref={communityRef}><section className="feed-column"><form className="composer-card" onSubmit={createPost}><div className="composer-title"><div className="avatar-small">{(profile.fullName || 'W')[0]}</div><div><strong>Share with your community</strong><small>Ask a question, share a win, or offer a resource.</small></div></div><textarea rows="3" value={postText} onChange={(event) => setPostText(event.target.value)} placeholder="What is on your mind?" maxLength="1200"/><div className="composer-footer"><small>{postText.length}/1200</small><button className="primary-btn" type="submit" disabled={!postText.trim()}>Share post</button></div></form>{posts.map((post) => <article className="post-card" key={post.id}><div className="post-author"><div className="avatar-small">{post.author[0]}</div><div><strong>{post.author}</strong><small>{post.role} · {post.time}</small></div></div><p className="post-content">{post.content}</p><div className="post-actions"><button type="button" onClick={() => toggleLike(post)} aria-label={`Like post by ${post.author}`}>? {post.likes} likes</button><span>{post.comments?.length || 0} comments</span></div>{post.comments?.map((comment) => <div className="comment" key={comment.id}><strong>{comment.author}</strong><span>{comment.text}</span></div>)}<form className="comment-form" onSubmit={(event) => addComment(event, post)}><input aria-label="Write a comment" value={commentDrafts[post.id] || ''} onChange={(event) => setCommentDrafts({ ...commentDrafts, [post.id]: event.target.value })} placeholder="Write a thoughtful comment..."/><button type="submit" className="text-action">Comment</button></form></article>)}</section><aside className="community-aside"><span className="eyebrow">Community care</span><h3>Make space for every voice.</h3><p>Lead with kindness, protect personal information, and keep conversations constructive.</p><div className="aside-stat"><strong>{posts.length}</strong><span>community conversations</span></div></aside></div>}
          {activeTab === 'admin' && <><section className="section-header"><span className="eyebrow">People-powered support</span><h2>Mentor & coordinator view</h2><p>Review incoming requests and recent activity. This demo view uses shared in-memory data.</p></section><div className="dashboard-grid">{[["Total requests", adminData?.stats.mentorshipRequests ?? 0, 'View requests', 'admin', requestListRef], ["Needs review", adminData?.stats.newRequests ?? 0, 'Review requests', 'admin', requestListRef], ["Job applications", adminData?.stats.jobApplications ?? 0, 'View applications', 'admin', applicationsRef], ["Community posts", adminData?.stats.communityPosts ?? 0, 'Open community', 'community', communityRef]].map(([label, value, action, tab, targetRef]) => <button className="dashboard-card dashboard-card-button" key={label} type="button" onClick={() => navigateToSection(tab, targetRef)}><span>{label}</span><strong>{value}</strong><small>{action}</small></button>)}</div><section className="admin-table-wrap" ref={requestListRef}><div className="table-heading"><h3>Recent mentorship requests</h3><span>{requests.length} requests</span></div><div className="request-list">{requests.map((item) => <article className="request-row" key={item.id}><div className="request-avatar">{item.name[0]}</div><div className="request-details"><strong>{item.name}</strong><span>{item.area} · {item.mentor}</span><p>{item.message}</p></div><div className="request-row-actions"><span className={`request-status ${item.status.toLowerCase()}`}>{item.status}</span><button className="delete-request-button" type="button" onClick={() => deleteMentorshipRequest(item)} aria-label={`Delete mentorship request from ${item.name}`}>Delete</button></div></article>)}</div>{requests.length === 0 && <p className="empty-requests">No mentorship requests to review.</p>}<div className="application-section" ref={applicationsRef}><div className="table-heading applications-heading"><h3>Recent job applications</h3><span>{adminData?.recentApplications?.length ?? 0} applications</span></div>{adminData?.recentApplications?.length > 0 ? adminData.recentApplications.map((application) => <div className="application-row" key={application.id}><div className="application-details"><strong>{application.name}</strong><span>{application.title} · {application.company}</span></div><button className="delete-request-button" type="button" onClick={() => deleteJobApplication(application)} aria-label={`Delete application for ${application.title} at ${application.company}`}>Delete</button></div>) : <p className="empty-requests">No job applications yet.</p>}</div></section><p className="demo-note">{adminData?.note}</p></>}
        </div>
      </main><footer className="footer"><p>Women Empowerment & Support Platform</p><span>Connecting skills, opportunities, and community</span></footer>
    </div>
  )
}

export default App
